This is an SDK for PlayStation 4 kernels! Support for 5.05 only right now!  
Created by Alexandro Sanchez Bach and maintained by golden

If you have some code you want to commit, just message me, open an issue, or make a pull request. I can add it or you can.
