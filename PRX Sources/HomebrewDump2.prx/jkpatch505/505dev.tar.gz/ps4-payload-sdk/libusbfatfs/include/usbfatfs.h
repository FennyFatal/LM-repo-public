#ifndef LIBUSBFATFS_H
#define LIBUSBFATFS_H

#include <ff.h>
#include <diskio.h>

#endif
