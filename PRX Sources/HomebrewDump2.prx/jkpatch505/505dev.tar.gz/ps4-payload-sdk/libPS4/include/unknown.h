#pragma once

int unknownResourceCreate(const char *name);
int unknownResourceDestroy(int unknownResource);
