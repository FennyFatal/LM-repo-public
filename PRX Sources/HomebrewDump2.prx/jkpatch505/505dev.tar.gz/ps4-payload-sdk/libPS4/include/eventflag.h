#pragma once

int createEventFlag(const char *name);
int destroyEventFlag(int eventFlag);
