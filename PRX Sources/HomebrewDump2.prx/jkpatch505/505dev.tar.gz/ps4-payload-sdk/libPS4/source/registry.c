#include "syscall.h"

#include "registry.h"

SYSCALL(registryCommand, 532);
