#include "syscall.h"

#include "barrier.h"

SYSCALL(barrierInit, 557);
SYSCALL(barrierDestroy, 558);
