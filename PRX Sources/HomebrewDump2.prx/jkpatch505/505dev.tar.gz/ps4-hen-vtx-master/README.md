# PS4HEN
Homebrew enabler for PS4

## Contributors
Massive credits to the following:

- [Flatz](https://twitter.com/flat_z)
- [idc](https://twitter.com/3226_2143)
- [Joon](https://twitter.com/joonie86)
- Anonymous
