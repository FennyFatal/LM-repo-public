/* golden */
/* 1/2/2018 */

#ifndef _JKPATCH_H
#define _JKPATCH_H

// stolen from windows, I prefer this for some reason
#define FALSE 0
#define TRUE 1

// libPS4
#include <ps4.h>

#include "magic.h"
#include "AMD.h"
#include "freebsd.h"
#include "utilities.h"
#include "resolve.h"

#endif
