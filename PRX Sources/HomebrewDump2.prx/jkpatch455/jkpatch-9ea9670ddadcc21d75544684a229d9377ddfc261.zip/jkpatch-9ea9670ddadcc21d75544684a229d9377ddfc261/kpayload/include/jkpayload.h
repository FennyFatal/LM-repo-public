/* golden */
/* 1/2/2018 */

#ifndef _PAYLOAD_H
#define _PAYLOAD_H

#include <stdint.h>
#include <stdarg.h>
#include "AMD.h"
#include "freebsd.h"
#include "magic.h"
#include "sparse.h"

#include "elf.h"
#include "defines.h"
#include "resolve.h"
#include "uart.h"
#include "utilities.h"

#endif
